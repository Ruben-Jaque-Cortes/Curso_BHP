// Obtenemos el botón por su id (ejemplo de tema anterior)
var cambiar = document.getElementById("cambiardef");

cambiar.addEventListener("click", function() {
    this.innerText = "Cerrar Sesión";
});



// OCULTAR BOTON DE AGREGAR DEFICIÓN
var addButton = document.getElementById("botondesaparecer");

addButton.addEventListener("click", function() {
    this.style.display = "none";
});



/* MENSAJE AL SELECCIONAR LIKE */
var buttons = document.querySelectorAll(".boton");

buttons.forEach(button => {
    button.addEventListener("click", function() {
        var title = this.parentElement.querySelector("h2").textContent;
        alert("Te gustó la definición de: " + title);
    });
});




/* CONTEO DE LIKES */
var likes = document.querySelectorAll(".boton");

likes.forEach(button => {
    button.addEventListener("click", function() {
        var likeSpan = this.nextElementSibling;
        let like = parseInt(likeSpan.textContent) || 0;
        like++;
        likeSpan.textContent = like + " Likes";
    });
});














